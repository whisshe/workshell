#!/bin/bash
if [ ! -d /tmp/test ];then
	mkdir -p /tmp/test
fi 
