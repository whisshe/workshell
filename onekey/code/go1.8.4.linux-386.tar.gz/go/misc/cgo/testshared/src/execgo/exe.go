package main

/*
 */
import "C"

func main() {
}
